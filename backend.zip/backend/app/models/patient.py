from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.database.connection import Base


class Patient(Base):
    __tablename__ = "patients"

    id = Column(
        Integer,
        primary_key=True,
        index=True,
    )

    user_id = Column(
        Integer,
        ForeignKey("users.id"),
        unique=True,
        nullable=False,
    )

    # ==================================================
    # PERSONAL INFORMATION
    # ==================================================

    date_of_birth = Column(
        Date,
        nullable=True,
    )

    gender = Column(
        String,
        nullable=True,
    )

    phone = Column(
        String,
        nullable=True,
    )

    address = Column(
        String,
        nullable=True,
    )

    city = Column(
        String,
        nullable=True,
    )

    state = Column(
        String,
        nullable=True,
    )

    zip_code = Column(
        String,
        nullable=True,
    )

    emergency_contact_name = Column(
        String,
        nullable=True,
    )

    emergency_contact_phone = Column(
        String,
        nullable=True,
    )

    # ==================================================
    # INSURANCE INFORMATION
    # ==================================================

    insurance_provider = Column(
        String,
        nullable=True,
    )

    insurance_member_id = Column(
        String,
        nullable=True,
    )

    # ==================================================
    # PRIMARY CARE PROVIDER
    # ==================================================

    pcp_doctor_id = Column(
        Integer,
        ForeignKey("doctors.id"),
        nullable=True,
    )

    # ==================================================
    # STATUS
    # ==================================================

    active = Column(
        Boolean,
        default=True,
        nullable=False,
    )

    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
    )

    # ==================================================
    # RELATIONSHIPS
    # ==================================================

    user = relationship(
        "User",
        back_populates="patient",
    )

    pcp_doctor = relationship(
        "Doctor",
        foreign_keys=[pcp_doctor_id],
    )

    appointments = relationship(
        "Appointment",
        back_populates="patient",
    )